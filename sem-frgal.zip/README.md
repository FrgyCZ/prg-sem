Top tier lobotomy no cap fr fr
