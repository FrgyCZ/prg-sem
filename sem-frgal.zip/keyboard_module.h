#ifndef __KEYBOARD_MODULE_H__
#define __KEYBOARD_MODULE_H__

void *keyboard_thread(void *d);

#endif
