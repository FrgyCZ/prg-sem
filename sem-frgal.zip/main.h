#ifndef __MAIN_H__
#define __MAIN_H__

void *main_thread(void *);

void debug_view(void);

#endif
